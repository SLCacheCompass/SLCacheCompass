@echo off
title Cache Compass Support Diagnostic
cd /d "%~dp0"

echo.
echo Cache Compass Support Diagnostic
echo ================================
echo.
echo Please leave Firestorm and Cache Compass open while this runs.
echo No Administrator access is required.
echo.
echo Running diagnostic...
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0CacheCompass-Diagnostic.ps1"

echo.
if exist "%~dp0CacheCompass-Diagnostic.txt" (
    echo Diagnostic complete.
    echo.
    echo Please attach this file to your support reply:
    echo "%~dp0CacheCompass-Diagnostic.txt"
    echo.
    explorer.exe /select,"%~dp0CacheCompass-Diagnostic.txt"
) else (
    echo The diagnostic file was not created.
    echo Please take a screenshot of this window and send it to Cache Compass Support.
    echo.
)

pause
