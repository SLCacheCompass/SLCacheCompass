﻿$ErrorActionPreference = "Continue"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Out = Join-Path $ScriptDir "CacheCompass-Diagnostic.txt"

function Write-Line {
    param([string]$Text = "")
    Add-Content -LiteralPath $Out -Value $Text -Encoding UTF8
}

"CACHE COMPASS SUPPORT DIAGNOSTIC" | Set-Content -LiteralPath $Out -Encoding UTF8

Write-Line "Created: $(Get-Date)"
Write-Line "Windows user: $env:USERNAME"
Write-Line "Output file: $Out"
Write-Line

Write-Line "=== WINDOWS ==="

try {
    $os = Get-CimInstance Win32_OperatingSystem
    Write-Line "Edition: $($os.Caption)"
    Write-Line "Version: $($os.Version)"
    Write-Line "Build: $($os.BuildNumber)"
} catch {
    Write-Line "Could not read Windows version: $($_.Exception.Message)"
}

Write-Line

try {
    Add-Type -AssemblyName System.Windows.Forms

    Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class CCWindowInfo {
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

    [DllImport("user32.dll")]
    public static extern uint GetDpiForWindow(IntPtr hWnd);
}
"@ -ErrorAction SilentlyContinue
} catch {
    Write-Line "Display helper warning: $($_.Exception.Message)"
}

Write-Line "=== MONITORS ==="

try {
    foreach ($screen in [System.Windows.Forms.Screen]::AllScreens) {
        Write-Line "Monitor: $($screen.DeviceName)"
        Write-Line "Primary: $($screen.Primary)"
        Write-Line "Bounds: $($screen.Bounds.X),$($screen.Bounds.Y) $($screen.Bounds.Width)x$($screen.Bounds.Height)"
        Write-Line "Working area: $($screen.WorkingArea.X),$($screen.WorkingArea.Y) $($screen.WorkingArea.Width)x$($screen.WorkingArea.Height)"
        Write-Line
    }
} catch {
    Write-Line "Could not read monitor information: $($_.Exception.Message)"
}

Write-Line "=== FIRESTORM AND CACHE COMPASS WINDOWS ==="

try {
    $Processes = Get-Process | Where-Object {
        $_.ProcessName -match "Firestorm|CacheCompass"
    }

    foreach ($p in $Processes) {
        Write-Line "Process: $($p.ProcessName)"
        Write-Line "PID: $($p.Id)"

        try {
            Write-Line "Path: $($p.Path)"

            if ($p.Path -and (Test-Path -LiteralPath $p.Path)) {
                $v = (Get-Item -LiteralPath $p.Path).VersionInfo
                Write-Line "File version: $($v.FileVersion)"
                Write-Line "Product version: $($v.ProductVersion)"
            }
        } catch {
            Write-Line "Could not read process path/version."
        }

        Write-Line "Window title: $($p.MainWindowTitle)"

        if ($p.MainWindowHandle -ne 0) {
            try {
                $rect = New-Object CCWindowInfo+RECT
                [CCWindowInfo]::GetWindowRect(
                    $p.MainWindowHandle,
                    [ref]$rect
                ) | Out-Null

                Write-Line "Window position: Left=$($rect.Left) Top=$($rect.Top) Right=$($rect.Right) Bottom=$($rect.Bottom)"

                $screen = [System.Windows.Forms.Screen]::FromHandle(
                    $p.MainWindowHandle
                )

                Write-Line "Window monitor: $($screen.DeviceName)"

                try {
                    $dpi = [CCWindowInfo]::GetDpiForWindow(
                        $p.MainWindowHandle
                    )

                    if ($dpi -gt 0) {
                        $scale = [math]::Round(($dpi / 96) * 100)
                        Write-Line "Window DPI: $dpi"
                        Write-Line "Approximate scaling: $scale%"
                    }
                } catch {
                    Write-Line "Window DPI unavailable."
                }
            } catch {
                Write-Line "Could not read window position."
            }
        }

        Write-Line
    }

    if (-not $Processes) {
        Write-Line "No running Firestorm or Cache Compass process detected."
        Write-Line
    }
} catch {
    Write-Line "Process scan failed: $($_.Exception.Message)"
    Write-Line
}

Write-Line "=== CACHE COMPASS FILES ==="

$CCDir = Join-Path $env:LOCALAPPDATA "CacheCompass"

Write-Line "Data folder: $CCDir"

if (Test-Path -LiteralPath $CCDir) {
    try {
        Get-ChildItem -LiteralPath $CCDir -File |
            Sort-Object LastWriteTime -Descending |
            Select-Object -First 20 |
            ForEach-Object {
                Write-Line "$($_.LastWriteTime)  $($_.Length) bytes  $($_.Name)"
            }
    } catch {
        Write-Line "Could not list Cache Compass files: $($_.Exception.Message)"
    }
} else {
    Write-Line "Cache Compass data folder not found."
}

Write-Line
Write-Line "=== LATEST MOVE JOURNAL ==="

$Journal = $null

if (Test-Path -LiteralPath $CCDir) {
    try {
        $Journal = Get-ChildItem -LiteralPath $CCDir -File |
            Where-Object {
                $_.Name -like "plan-*.journal.jsonl"
            } |
            Sort-Object LastWriteTime -Descending |
            Select-Object -First 1
    } catch {}
}

if ($Journal) {
    Write-Line "Journal: $($Journal.FullName)"
    Write-Line "Modified: $($Journal.LastWriteTime)"
    Write-Line

    try {
        Get-Content -LiteralPath $Journal.FullName -Tail 120 |
            Add-Content -LiteralPath $Out -Encoding UTF8
    } catch {
        Write-Line "Could not read move journal: $($_.Exception.Message)"
    }
} else {
    Write-Line "No move journal found."
}

Write-Line
Write-Line "=== CACHE COMPASS STARTUP ERROR ==="

$StartupError = Join-Path $CCDir "startup-error.txt"

if (Test-Path -LiteralPath $StartupError) {
    try {
        Get-Content -LiteralPath $StartupError -Tail 100 |
            Add-Content -LiteralPath $Out -Encoding UTF8
    } catch {
        Write-Line "Could not read startup-error.txt."
    }
} else {
    Write-Line "No startup-error.txt found."
}

Write-Line
Write-Line "=== FIRESTORM INVENTORY CACHE ==="

$FSCache = Join-Path $env:LOCALAPPDATA "Firestorm_x64"

Write-Line "Firestorm cache folder: $FSCache"

if (Test-Path -LiteralPath $FSCache) {
    try {
        Get-ChildItem -LiteralPath $FSCache -Filter "*.inv.llsd.gz" -File -Recurse |
            Sort-Object LastWriteTime -Descending |
            Select-Object -First 8 |
            ForEach-Object {
                Write-Line "$($_.LastWriteTime)  $($_.Length) bytes  $($_.FullName)"
            }
    } catch {
        Write-Line "Could not scan Firestorm inventory cache."
    }
} else {
    Write-Line "Firestorm cache folder not found."
}

Write-Line
Write-Line "=== RECENT FIRESTORM LOG MESSAGES ==="

$FSLog = Join-Path $env:APPDATA "Firestorm_x64\logs\Firestorm.log"

if (Test-Path -LiteralPath $FSLog) {
    Write-Line "Log: $FSLog"
    Write-Line "Modified: $((Get-Item -LiteralPath $FSLog).LastWriteTime)"
    Write-Line

    try {
        Get-Content -LiteralPath $FSLog -Tail 2500 |
            Where-Object {
                $_ -match "(?i)inventory|trash|move|AIS|error|warning|failed|failure"
            } |
            Select-Object -Last 250 |
            Add-Content -LiteralPath $Out -Encoding UTF8
    } catch {
        Write-Line "Could not read Firestorm.log: $($_.Exception.Message)"
    }
} else {
    Write-Line "Firestorm.log not found."
}

Write-Line
Write-Line "=== END DIAGNOSTIC ==="

Write-Host ""
Write-Host "Diagnostic complete."
Write-Host "Please attach this file to your reply:"
Write-Host $Out
