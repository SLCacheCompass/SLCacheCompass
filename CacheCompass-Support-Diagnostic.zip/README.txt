CACHE COMPASS SUPPORT DIAGNOSTIC

1. Extract this ZIP to a normal folder.
2. Open Firestorm and let inventory finish loading.
3. Open Cache Compass.
4. Reproduce the failed move once.
5. Leave Firestorm and Cache Compass open.
6. Double-click "Run Cache Compass Diagnostic.cmd".
7. When it finishes, Windows should highlight "CacheCompass-Diagnostic.txt".
8. Attach that TXT file to your reply to Cache Compass Support.

This diagnostic does not make changes to Firestorm, Cache Compass, or your Second Life inventory.
It does not require Administrator access.
